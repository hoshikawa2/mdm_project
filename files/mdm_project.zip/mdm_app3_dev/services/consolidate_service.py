# services/consolidate_service.py
from __future__ import annotations
from typing import List, Dict, Any, Tuple, DefaultDict
from collections import defaultdict
import re

# ---------- Similarity (RapidFuzz preferred; fallback to difflib) ----------
try:
    from rapidfuzz import fuzz
    def _sim(a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        return fuzz.token_set_ratio(a, b) / 100.0
except Exception:
    from difflib import SequenceMatcher
    def _sim(a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        return SequenceMatcher(None, a.lower().strip(), b.lower().strip()).ratio()

# ---------- Helpers ----------
_digits_re = re.compile(r"\D+")
def only_digits(x: str | None) -> str | None:
    if not x: return None
    return _digits_re.sub("", x)

def lower_strip(x: str | None) -> str | None:
    if not x: return None
    return x.strip().lower()

def identity(x): return x

# ---------- DSU (Union-Find) ----------
class DSU:
    def __init__(self, n: int):
        self.p = list(range(n))
        self.r = [0] * n
    def find(self, x: int) -> int:
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x
    def union(self, a: int, b: int):
        ra, rb = self.find(a), self.find(b)
        if ra == rb: return
        if self.r[ra] < self.r[rb]:
            self.p[ra] = rb
        elif self.r[ra] > self.r[rb]:
            self.p[rb] = ra
        else:
            self.p[rb] = ra
            self.r[ra] += 1

# ---------- Priority + Merge ----------
def _priority_score(rec: Dict[str, Any], policies: Dict[str, Any]) -> Tuple[int, int]:
    source_priority_default = {"ERP": 4, "CRM": 3, "POS": 2, "WEB": 1, "APP": 1, "LOYALTY": 1, "MARKETING": 1, "SUPPORT": 1}
    source_priority = policies.get("source_priority", source_priority_default)
    src = (rec.get("source") or "").upper()
    sp = int(source_priority.get(src, 0))
    completeness = sum(1 for v in rec.values() if v not in (None, "", [], {}))
    return (sp, completeness)

def _merge_cluster(records: List[Dict[str, Any]], policies: Dict[str, Any]) -> Dict[str, Any]:
    if not records: return {}
    ordered = sorted(records, key=lambda r: _priority_score(r, policies), reverse=True)
    golden = {**ordered[0]}
    for r in ordered[1:]:
        for k, v in r.items():
            if k.startswith("_"): 
                continue
            if golden.get(k) in (None, "", [], {}):
                if v not in (None, "", [], {}):
                    golden[k] = v
    return golden

# ---------- Core consolidation ----------
def consolidate_many(records: List[Dict[str, Any]], policies: Dict[str, Any]) -> Dict[str, Any]:
    """
    100% coverage clustering:
    - Start with all singletons.
    - Union by exact "hard keys" (optional).
    - Union by fuzzy similarity on selected fields.
    """

    n = len(records)
    if n == 0:
        return {"golden_record": None, "golden_records": [], "matches": []}

    dsu = DSU(n)

    # 1) Hard keys (exact match after normalization) --------------------------
    # Example policies:
    #   hard_keys = ["cpf","cnpj","email"]
    #   normalizers = {"cpf":"digits", "cnpj":"digits", "email":"lower"}
    hard_keys: List[str] = policies.get("hard_keys", [])
    norm_map = {
        "digits": only_digits,
        "lower": lower_strip,
        "identity": identity,
    }
    key_normalizers: Dict[str, str] = policies.get("normalizers", {})

    for key in hard_keys:
        buckets: DefaultDict[str, List[int]] = defaultdict(list)
        norm_fn = norm_map.get(key_normalizers.get(key, "identity"), identity)
        for i, r in enumerate(records):
            val = r.get(key)
            norm = norm_fn(val) if isinstance(val, str) or val is not None else None
            if norm:
                buckets[str(norm)].append(i)
        for idxs in buckets.values():
            for i in range(1, len(idxs)):
                dsu.union(idxs[0], idxs[i])

    # 2) Fuzzy similarity unions ---------------------------------------------
    fields: List[str] = policies.get("cluster_fields", ["name", "email", "phone", "address"])
    threshold = float(policies.get("dedupe_threshold", 0.87))

    # Compute pairs on-demand; we always union onto the global DSU
    for i in range(n):
        ai = records[i]
        for j in range(i + 1, n):
            aj = records[j]
            sims = []
            for f in fields:
                sims.append(_sim(str(ai.get(f, "")), str(aj.get(f, ""))))
            if not sims:
                continue
            score = sum(sims) / len(sims)
            if score >= threshold:
                dsu.union(i, j)

    # 3) Collect clusters (coverage = 100%) ----------------------------------
    groups: DefaultDict[int, List[int]] = defaultdict(list)
    for i in range(n):
        groups[dsu.find(i)].append(i)
    clusters_idx = list(groups.values())

    # 4) Build goldens + matches ---------------------------------------------
    # Sort clusters by size desc, then by best priority score desc (stable)
    def cluster_key(idxs: List[int]) -> Tuple[int, Tuple[int,int]]:
        cl = [records[i] for i in idxs]
        best = max((_priority_score(r, policies) for r in cl), default=(0,0))
        return (len(idxs), best)

    clusters_idx.sort(key=cluster_key, reverse=True)

    golden_records, matches = [], []
    for idxs in clusters_idx:
        cl = [records[i] for i in idxs]
        golden = _merge_cluster(cl, policies)
        golden_records.append(golden)
        mids = [r.get("id") for r in cl]
        matches.append({
            "golden_id": golden.get("id"),
            "cluster_size": len(cl),
            "members": mids,
            "merged_from": [m for m in mids if m != golden.get("id")]
        })

    return {
        "golden_records": golden_records,
        "matches": matches
    }
